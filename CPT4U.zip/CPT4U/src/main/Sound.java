package main;

import java.net.URL;

import javax.sound.sampled.Clip;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioInputStream;

public class Sound {
  Clip clip;
  URL soundURL[] = new URL[30];

  public Sound() {
    soundURL[0] = getClass().getResource("/Sound/themev1.wav");
    soundURL[1] = getClass().getResource("/Sound/key.wav");
    soundURL[2] = getClass().getResource("/Sound/unlock.wav");
    soundURL[3] = getClass().getResource("/Sound/upgrade.wav");
    soundURL[4] = getClass().getResource("/Sound/shoot.wav");
  }

  public void setFile(int i) {
    try {
      AudioInputStream ais = AudioSystem.getAudioInputStream(soundURL[i]);
      clip = AudioSystem.getClip();
      clip.open(ais);
      
    }catch(Exception e){   
    }
  }

  public void play() {
    clip.start();
  }

  public void loop() {
    clip.loop(Clip.LOOP_CONTINUOUSLY);
  }

  public void stop() {
    clip.stop();
  }
}